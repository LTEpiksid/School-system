import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.swing.*;

public class LoginForm extends JFrame {
    final private Font mainFont = new Font("Segoe print", Font.BOLD, 18);
    JTextField tfUsername;
    JPasswordField pfPassword;

    public void initialize() {
        /* Form Panel */
        JLabel lbLoginForm = new JLabel("Prisijungimas", SwingConstants.CENTER);
        lbLoginForm.setFont(mainFont);

        JLabel lbUsername = new JLabel("Username");
        lbUsername.setFont(mainFont);

        tfUsername = new JTextField();
        tfUsername.setFont(mainFont);

        JLabel lbPassword = new JLabel("Password");
        lbPassword.setFont(mainFont);

        pfPassword = new JPasswordField();
        pfPassword.setFont(mainFont);

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(0, 1, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        formPanel.add(lbLoginForm);
        formPanel.add(lbUsername);
        formPanel.add(tfUsername);
        formPanel.add(lbPassword);
        formPanel.add(pfPassword);

        /* Buttons Panel */
        JButton btnLogin = new JButton("Prisijungti");
        btnLogin.setFont(mainFont);
        btnLogin.addActionListener(new ActionListener() {

            @Override
        public void actionPerformed(ActionEvent e) {
        String username = tfUsername.getText();
        String password = String.valueOf(pfPassword.getPassword());

        User user = getAuthenticatedUser(username, password);

        if (user != null) {
            if ("Student".equals(user.level)) {
            StudentFrame studentFrame = new StudentFrame();
            studentFrame.initialize(user);
            } else if ("Teacher".equals(user.level)) {
            TeacherFrame teacherStudentsFrame = new TeacherFrame();
            teacherStudentsFrame.initialize(user);
            } else if ("Admin".equals(user.level)) {
            AdminFrame adminFrame = new AdminFrame();
            adminFrame.initialize();
            }
            dispose();
            } else {
            JOptionPane.showMessageDialog(LoginForm.this,
                "Username arba password netinka",
                "Try again",
                JOptionPane.ERROR_MESSAGE);
        }
    }

        });

        JButton btnCancel = new JButton("Atšaukti");
        btnCancel.setFont(mainFont);
        btnCancel.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }

        });

        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new GridLayout(1, 2, 10, 0));
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        buttonsPanel.add(btnLogin);
        buttonsPanel.add(btnCancel);

        /* Initialize the frame */
        add(formPanel, BorderLayout.NORTH);
        add(buttonsPanel, BorderLayout.SOUTH);

        setTitle("Prisijungimas");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(400, 500);
        setMinimumSize(new Dimension(350, 450));
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private User getAuthenticatedUser(String username, String password) {
    User user = null;

    final String DB_URL = "jdbc:mysql://localhost/student?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "";

    try {
        Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);

        String sql = "SELECT * FROM users WHERE username=? AND password=?";
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
        preparedStatement.setString(1, username);
        preparedStatement.setString(2, password);

        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            user = new User();
            user.username = resultSet.getString("username");
            user.password = resultSet.getString("password");
            user.level = resultSet.getString("level");
            user.groupe = resultSet.getString("groupe"); // Retrieve and set 'groupe'
        }

        preparedStatement.close();
        conn.close();

    } catch (Exception e) {
        e.printStackTrace();  // Print the exception for debugging purposes
        System.out.println("Database connection failed!");
    }

    return user;
}


    public static void main(String[] args) {
        LoginForm loginForm = new LoginForm();
        loginForm.initialize();
    }
}
