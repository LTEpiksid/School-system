import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class StudentFrame extends JFrame {

    public void initialize(User user) {
        JPanel panel = new JPanel(new BorderLayout());

        // Display labels in the middle-top
        JLabel middleTopLabel = new JLabel(user.username + " " + user.password, SwingConstants.CENTER);
        middleTopLabel.setFont(new Font("Segoe Print", Font.BOLD, 18));
        middleTopLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        // Additional label for "PAŽYMIAI"
        JLabel gradesLabel = new JLabel("PAŽYMIAI", SwingConstants.CENTER);
        gradesLabel.setFont(new Font("Segoe Print", Font.BOLD, 20));
        gradesLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        // Add Username, Password, and Groupe from the provided User object
        JPanel infoPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        infoPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        infoPanel.add(new JLabel("Username"));
        infoPanel.add(new JLabel(user.username));
        infoPanel.add(new JLabel("Password"));
        infoPanel.add(new JLabel(user.password));
        infoPanel.add(new JLabel("Grupe")); // Add Groupe label
        infoPanel.add(new JLabel(user.groupe)); // Add Groupe information



        // JTable to display grades
        JTable gradeTable = new JTable();
        gradeTable.setEnabled(false); // Make the table non-editable
        JScrollPane scrollPane = new JScrollPane(gradeTable);
        setupGradeTable(gradeTable, user);

        panel.add(middleTopLabel, BorderLayout.NORTH);
        panel.add(gradesLabel, BorderLayout.CENTER);
        panel.add(infoPanel, BorderLayout.SOUTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        setTitle("Studento pažymiai");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(800, 400);
        setLocationRelativeTo(null);
        add(panel);
        setVisible(true);
    }

    private void setupGradeTable(JTable gradeTable, User user) {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                // Use String class for all columns to handle both text and numeric values
                return String.class;
            }
        };
        gradeTable.setModel(model);

        // Subjects and months
        String[] subjects = {"Lie", "Mat", "Bio", "Ist", "Ang", "Fiz"};
        String[] months = {"Rugsejis", "Spalis", "Lapkritis", "Gruodis"};

        // Set column headers
        model.addColumn("");
        for (String subject : subjects) {
            model.addColumn(subject);
        }

        // Set row headers and data
        for (String month : months) {
            Object[] rowData = getGrades(user, month, subjects);
            model.addRow(rowData);
        }

        // Set row headers
        for (int i = 0; i < months.length; i++) {
            model.setValueAt(months[i], i, 0);
        }

        // Center-align the numbers in each cell
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < gradeTable.getColumnCount(); i++) {
            gradeTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        // Adjust column widths for a better look
        gradeTable.getColumnModel().getColumn(0).setPreferredWidth(100); // Month column width
        for (int i = 1; i < gradeTable.getColumnCount(); i++) {
            gradeTable.getColumnModel().getColumn(i).setPreferredWidth(50); // Subject columns width
        }
    }

    private Object[] getGrades(User user, String month, String[] subjects) {
        Object[] rowData = new Object[subjects.length + 1];
        rowData[0] = month;
    
        final String DB_URL = "jdbc:mysql://localhost/student?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
    
        try (Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "SELECT grade FROM subject_grades " +
                    "WHERE user_id = ? " +
                    "AND date_id = (SELECT date_id FROM dates WHERE date_name = ?) " +
                    "AND subject_id IN (SELECT subject_id FROM subjects WHERE subject_name = ?)";
    
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, getUserId(user.username));
                preparedStatement.setString(2, month);
    
                for (int i = 0; i < subjects.length; i++) {
                    preparedStatement.setString(3, subjects[i]);
                    try (ResultSet resultSet = preparedStatement.executeQuery()) {
                        if (resultSet.next()) {
                            // Use getInt to remove decimals
                            rowData[i + 1] = resultSet.getInt("grade");
                        } else {
                            rowData[i + 1] = ""; // No grade found
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
        return rowData;
    }

    private int getUserId(String username) throws SQLException {
        final String DB_URL = "jdbc:mysql://localhost/student?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";

        try (Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "SELECT id FROM users WHERE username = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, username);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        return resultSet.getInt("id");
                    }
                }
            }
        }

        throw new SQLException("User not found");
    }

    public static User getUserByLevel(String level) {
        User user = null;
        final String DB_URL = "jdbc:mysql://localhost/student?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
    
        try (Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "SELECT * FROM users WHERE level = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, level);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        user = new User();
                        user.username = resultSet.getString("username");
                        user.password = resultSet.getString("password");
                        user.level = resultSet.getString("level");
                        user.groupe = resultSet.getString("groupe");  // Add this line to retrieve the 'groupe' field
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }
    


    public static void main(String[] args) {
        User studentUser = getUserByLevel("Student");
        if (studentUser != null) {
            SwingUtilities.invokeLater(() -> {
                StudentFrame studentFrame = new StudentFrame();
                studentFrame.initialize(studentUser);
            });
        } else {
            System.out.println("No student found.");
        }
    }
}
