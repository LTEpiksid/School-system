import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class RegistrationFrame extends JFrame {
    private JTable usersTable;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;

    public RegistrationFrame() {
        initialize();
        loadUserData();
        setVisible(true);
    }

    void initialize() {
        setTitle("Registravimas");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // Create components
        usersTable = new JTable();
        JScrollPane tableScrollPane = new JScrollPane(usersTable);

        addButton = new JButton("Pridėti");
        editButton = new JButton("Redaguoti");
        deleteButton = new JButton("Ištrinti");

        // Set layout
        setLayout(new BorderLayout());

        // Add components to the frame
        add(tableScrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Add action listeners
        addButton.addActionListener(e -> addUser());
        editButton.addActionListener(e -> editUser());
        deleteButton.addActionListener(e -> deleteUser());

        // Add ListSelectionListener to handle row selection
        ListSelectionModel selectionModel = usersTable.getSelectionModel();
        selectionModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        selectionModel.addListSelectionListener(e -> handleRowSelection());

        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) {
                    return Boolean.class;
                }
                return super.getColumnClass(columnIndex);
            }
        };

        usersTable.setModel(model);

        TableColumnModel columnModel = usersTable.getColumnModel();
        TableColumn checkboxColumn = new TableColumn(columnModel.getColumnCount());
        checkboxColumn.setHeaderValue("Select");
        checkboxColumn.setCellRenderer(new CheckBoxRenderer());
        checkboxColumn.setCellEditor(new CheckBoxEditor(new JCheckBox()));
        columnModel.addColumn(checkboxColumn);

        // Include the checkbox column in the selection model
        selectionModel.addListSelectionListener(e -> handleRowSelection());
    }

    private void loadUserData() {
        try (Connection connection = AdminFrame.getConnection()) {
            String query = "SELECT * FROM users";
            try (PreparedStatement statement = connection.prepareStatement(query);
                 ResultSet resultSet = statement.executeQuery()) {

                if (resultSet != null) {
                    // Convert ResultSet to DefaultTableModel
                    DefaultTableModel tableModel = new DefaultTableModel() {
                        // Override isCellEditable method to make cells in the first column (checkboxes) non-editable
                        @Override
                        public boolean isCellEditable(int row, int column) {
                            return column != 0; // Allow editing only for columns other than the first one
                        }
                    };
                    ResultSetMetaData metaData = resultSet.getMetaData();
                    int columnCount = metaData.getColumnCount();

                    // Add column names to the model
                    for (int column = 1; column <= columnCount; column++) {
                        tableModel.addColumn(metaData.getColumnLabel(column));
                    }

                    // Add data to the model
                    while (resultSet.next()) {
                        Object[] rowData = new Object[columnCount];
                        for (int column = 1; column <= columnCount; column++) {
                            rowData[column - 1] = resultSet.getObject(column);
                        }
                        tableModel.addRow(rowData);
                    }

                    // Set the model to the JTable
                    usersTable.setModel(tableModel);
                } else {
                    JOptionPane.showMessageDialog(this, "ResultSet is null", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error executing query", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error connecting to the database", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleRowSelection() {
        int selectedRow = usersTable.getSelectedRow();
        deleteButton.setEnabled(selectedRow != -1);
        editButton.setEnabled(selectedRow != -1);
    }

    private void deleteUser() {
        int selectedRow = usersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Select a user to delete", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int userId = (int) usersTable.getValueAt(selectedRow, 0);

        try (Connection connection = AdminFrame.getConnection()) {
            // Delete the user from the 'users' table
            String deleteQuery = "DELETE FROM users WHERE id = ?";
            try (PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {
                deleteStatement.setInt(1, userId);
                deleteStatement.executeUpdate();
            }

            // Reload the user data in the table
            loadUserData();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting user", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addUser() {
        // Implement logic to add a new user
        // You can use a dialog to get user input and then insert a new record into the 'users' table

        // Create a simple dialog for user input
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JTextField levelField = new JTextField();
        JTextField groupField = new JTextField();

        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        inputPanel.add(new JLabel("Username:"));
        inputPanel.add(usernameField);
        inputPanel.add(new JLabel("Password:"));
        inputPanel.add(passwordField);
        inputPanel.add(new JLabel("Level:"));
        inputPanel.add(levelField);
        inputPanel.add(new JLabel("Group:"));
        inputPanel.add(groupField);

        int result = JOptionPane.showConfirmDialog(
                this,
                inputPanel,
                "Add User",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            try (Connection connection = AdminFrame.getConnection()) {
                // Check if the username already exists
                String checkQuery = "SELECT * FROM users WHERE username = ?";
                try (PreparedStatement checkStatement = connection.prepareStatement(checkQuery)) {
                    checkStatement.setString(1, usernameField.getText());
                    if (checkStatement.executeQuery().next()) {
                        JOptionPane.showMessageDialog(this, "Username already exists", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                // Insert the new user into the 'users' table
                String insertQuery = "INSERT INTO users (username, password, level, groupe) VALUES (?, ?, ?, ?)";
                try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
                    insertStatement.setString(1, usernameField.getText());
                    insertStatement.setString(2, new String(passwordField.getPassword()));
                    insertStatement.setString(3, levelField.getText());
                    insertStatement.setString(4, groupField.getText());

                    insertStatement.executeUpdate();
                }

                // Reload the user data in the table
                loadUserData();

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error adding user", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void editUser() {
        int selectedRow = usersTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Select a user to edit", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Get the data of the selected user
        int userId = (int) usersTable.getValueAt(selectedRow, 0);
        String currentUsername = (String) usersTable.getValueAt(selectedRow, 1);
        String currentPassword = (String) usersTable.getValueAt(selectedRow, 2);
        String currentLevel = (String) usersTable.getValueAt(selectedRow, 3);
        String currentGroup = (String) usersTable.getValueAt(selectedRow, 4);

        // Declare the input fields here
        JTextField usernameField = new JTextField(currentUsername);
        JPasswordField passwordField = new JPasswordField(currentPassword);
        JTextField levelField = new JTextField(currentLevel);
        JTextField groupField = new JTextField(currentGroup);

        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        inputPanel.add(new JLabel("Username:"));
        inputPanel.add(usernameField);
        inputPanel.add(new JLabel("Password:"));
        inputPanel.add(passwordField);
        inputPanel.add(new JLabel("Level:"));
        inputPanel.add(levelField);
        inputPanel.add(new JLabel("Group:"));
        inputPanel.add(groupField);

        int result = JOptionPane.showConfirmDialog(
                this,
                inputPanel,
                "Edit User",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            try (Connection connection = AdminFrame.getConnection()) {
                // Check if the edited username already exists
                String checkQuery = "SELECT * FROM users WHERE username = ? AND id != ?";
                try (PreparedStatement checkStatement = connection.prepareStatement(checkQuery)) {
                    checkStatement.setString(1, usernameField.getText());
                    checkStatement.setInt(2, userId);
                    if (checkStatement.executeQuery().next()) {
                        JOptionPane.showMessageDialog(this, "Username already exists", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                // Update the user in the 'users' table
                String updateQuery = "UPDATE users SET username = ?, password = ?, level = ?, groupe = ? WHERE id = ?";
                try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                    updateStatement.setString(1, usernameField.getText());
                    updateStatement.setString(2, new String(passwordField.getPassword()));
                    updateStatement.setString(3, levelField.getText());
                    updateStatement.setString(4, groupField.getText());
                    updateStatement.setInt(5, userId);

                    updateStatement.executeUpdate();
                }

                // Reload the user data in the table
                loadUserData();

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error editing user", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    class CheckBoxRenderer extends DefaultTableCellRenderer {
        private final JCheckBox checkBox;

        public CheckBoxRenderer() {
            checkBox = new JCheckBox();
            checkBox.setHorizontalAlignment(JCheckBox.CENTER);
        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (value != null)
                checkBox.setSelected((Boolean) value);
            return checkBox;
        }
    }

    class CheckBoxEditor extends DefaultCellEditor {
        private final JCheckBox checkBox;

        public CheckBoxEditor(JCheckBox checkBox) {
            super(checkBox);
            this.checkBox = checkBox;
            checkBox.setHorizontalAlignment(JCheckBox.CENTER);
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            if (value != null)
                checkBox.setSelected((Boolean) value);
            return checkBox;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            RegistrationFrame registrationFrame = new RegistrationFrame();
            registrationFrame.initialize();
        });
    }
}
