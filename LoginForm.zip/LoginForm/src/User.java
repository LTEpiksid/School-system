public class User {
    public final String type = null;
    public String username;
    public String password;
    public String level;
    public String groupe;
}
