import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class AllStudentsFrame extends JFrame {

    public void initialize() {
        JPanel panel = new JPanel(new BorderLayout());

        JLabel titleLabel = new JLabel("Studentai", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe Print", Font.BOLD, 20));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        DefaultTableModel model = new DefaultTableModel();
        JTable studentsTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(studentsTable);
        setupStudentsTable(model);

        JButton viewButton = new JButton("Peržiūrėti");
        viewButton.addActionListener(e -> {
            int selectedRow = studentsTable.getSelectedRow();
            if (selectedRow != -1) {
                String selectedStudentInfo = (String) studentsTable.getValueAt(selectedRow, 0);
                openStudentGradesWindow(selectedStudentInfo);
            } else {
                JOptionPane.showMessageDialog(AllStudentsFrame.this,
                        "Nepasirinkote studento.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(viewButton, BorderLayout.EAST);

        setTitle("Visų studentų langas");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);
        add(panel);
        setVisible(true);
    }
    private int getSubjectId(String subjectName) throws SQLException {
        try (Connection connection = AdminFrame.getConnection()) {
            String query = "SELECT subject_id FROM subjects WHERE subject_name = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, subjectName);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        return resultSet.getInt("subject_id");
                    }
                }
            }
        }
        throw new SQLException("Subject not found");
    }
    
    private void setupStudentsTable(DefaultTableModel model) {
        final String DB_URL = "jdbc:mysql://localhost/student?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
    
        try (Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "SELECT username, password, groupe FROM users WHERE level = 'Student' ORDER BY groupe, username";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(query)) {
    
                // Add the column outside the loop
                model.addColumn("Sąrašas");
    
                while (resultSet.next()) {
                    String studentInfo = resultSet.getString("username") + " " + resultSet.getString("password") +
                            " (" + resultSet.getString("groupe") + ")";
                    model.addRow(new Object[]{studentInfo});
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    

    private void openStudentGradesWindow(String studentInfo) {
        // Extract username from the combined string
        String studentUsername = studentInfo.split(" ")[0];

        // Create a new frame for displaying student grades
        JFrame studentGradesFrame = new JFrame();
        JPanel panel = new JPanel(new BorderLayout());
        DefaultTableModel model = new DefaultTableModel();
        JTable gradeTable = new JTable(model);

        JButton saveButton = new JButton("Išsaugoti");
        saveButton.addActionListener(e -> saveStudentGrades(studentUsername, model));

        JScrollPane scrollPane = new JScrollPane(gradeTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(saveButton, BorderLayout.SOUTH);

        setupGradeTable(model, studentUsername);

        studentGradesFrame.setTitle("Studentu pažymiai - " + studentInfo);
        studentGradesFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        studentGradesFrame.setSize(600, 400);
        studentGradesFrame.setLocationRelativeTo(null);
        studentGradesFrame.add(panel);
        studentGradesFrame.setVisible(true);
    }

    private void setupGradeTable(DefaultTableModel model, String studentUsername) {
        final String DB_URL = "jdbc:mysql://localhost/student?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
    
        try (Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "SELECT subject_name, date_name, MAX(grade) AS grade FROM subject_grades sg " +
                    "JOIN subjects s ON sg.subject_id = s.subject_id " +
                    "JOIN dates d ON sg.date_id = d.date_id " +
                    "WHERE user_id = ? " +
                    "GROUP BY subject_name, date_name";
    
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, getUserId(studentUsername));
    
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    model.addColumn("Dalykas");
                    model.addColumn("Data");
                    model.addColumn("Pažimys");
    
                    while (resultSet.next()) {
                        String subjectName = resultSet.getString("subject_name");
                        String dateName = resultSet.getString("date_name");
                        int grade = resultSet.getInt("grade");
    
                        model.addRow(new Object[]{subjectName, dateName, grade});
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    

    private int getUserId(String username) throws SQLException {
        final String DB_URL = "jdbc:mysql://localhost/student?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";

        try (Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "SELECT id FROM users WHERE username = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, username);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        return resultSet.getInt("id");
                    }
                }
            }
        }

        throw new SQLException("User not found");
    }

    private void saveStudentGrades(String studentUsername, DefaultTableModel model) {
    final String DB_URL = "jdbc:mysql://localhost/student?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "";
    Connection connection = null;

    try {
        connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
        connection.setAutoCommit(false);

        for (int i = 0; i < model.getRowCount(); i++) {
            String subjectName = (String) model.getValueAt(i, 0);  // Assuming subject is in the first column
            String dateName = (String) model.getValueAt(i, 1);     // Assuming date is in the second column
            Object gradeObj = model.getValueAt(i, 2);              // Assuming grade is in the third column

            // Check if the grade is not null and is a valid number
            if (gradeObj != null && gradeObj instanceof Number) {
                float grade = ((Number) gradeObj).floatValue();

                int subjectId = getSubjectId(subjectName);
                int userId = getUserId(studentUsername);

                // Check if the record exists for the specified user, subject, and date
                String checkRecordQuery = "SELECT * FROM subject_grades " +
                        "WHERE user_id = ? AND subject_id = ? AND date_id = (SELECT date_id FROM dates WHERE date_name = ?)";

                try (PreparedStatement checkRecordStatement = connection.prepareStatement(checkRecordQuery)) {
                    checkRecordStatement.setInt(1, userId);
                    checkRecordStatement.setInt(2, subjectId);
                    checkRecordStatement.setString(3, dateName);

                    try (ResultSet checkRecordResultSet = checkRecordStatement.executeQuery()) {
                        if (checkRecordResultSet.next()) {
                            // Update the existing record
                            String updateQuery = "UPDATE subject_grades " +
                                    "SET grade = ? " +
                                    "WHERE user_id = ? AND subject_id = ? AND date_id = (SELECT date_id FROM dates WHERE date_name = ?)";

                            try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                                updateStatement.setFloat(1, grade);
                                updateStatement.setInt(2, userId);
                                updateStatement.setInt(3, subjectId);
                                updateStatement.setString(4, dateName);

                                updateStatement.executeUpdate();
                            }
                        } else {
                            // Insert a new record if it doesn't exist
                            String insertQuery = "INSERT INTO subject_grades (user_id, subject_id, date_id, grade) " +
                                    "VALUES (?, ?, (SELECT date_id FROM dates WHERE date_name = ?), ?)";

                            try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
                                insertStatement.setInt(1, userId);
                                insertStatement.setInt(2, subjectId);
                                insertStatement.setString(3, dateName);
                                insertStatement.setFloat(4, grade);

                                insertStatement.executeUpdate();
                            }
                        }
                    }
                }
            }
        }

        connection.commit();
        JOptionPane.showMessageDialog(this,
                "Sėkmingai išsaugota.",
                "Pavyko",
                JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this,
                        "Error updating grades: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
        
                try {
                    if (connection != null) {
                        connection.rollback();
                    }
                } catch (SQLException rollbackException) {
                    rollbackException.printStackTrace();
                }
            } finally {
                try {
                    if (connection != null) {
                        connection.close();
                    }
                } catch (SQLException closeException) {
                    closeException.printStackTrace();
                }
            }
        }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AllStudentsFrame allStudentsFrame = new AllStudentsFrame();
            allStudentsFrame.initialize();
        });
    }
}
