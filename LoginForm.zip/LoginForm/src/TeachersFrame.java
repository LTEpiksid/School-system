import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TeachersFrame extends JFrame {

    public void initialize() {
        JPanel panel = new JPanel(new BorderLayout());

        JLabel titleLabel = new JLabel("Mokytojai", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe Print", Font.BOLD, 20));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        DefaultTableModel model = new DefaultTableModel();
        JTable teachersTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(teachersTable);
        setupTeachersTable(model);

        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        setTitle("Mokytojų langas");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);
        add(panel);
        setVisible(true);
    }

    private void setupTeachersTable(DefaultTableModel model) {
        final String DB_URL = "jdbc:mysql://localhost/student?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";

        try (Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "SELECT username, password, subject_name FROM users " +
                    "JOIN teacher_subjects ts ON users.id = ts.user_id " +
                    "JOIN subjects s ON ts.subject_id = s.subject_id " +
                    "WHERE level = 'Teacher' ORDER BY username";
            try (PreparedStatement statement = connection.prepareStatement(query);
                 ResultSet resultSet = statement.executeQuery()) {

                model.addColumn("Vartotojas");
                model.addColumn("Slaptažodis");
                model.addColumn("Dalykas");

                while (resultSet.next()) {
                    String username = resultSet.getString("username");
                    String password = resultSet.getString("password");
                    String subject = resultSet.getString("subject_name");

                    model.addRow(new Object[]{username, password, subject});
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TeachersFrame teachersFrame = new TeachersFrame();
            teachersFrame.initialize();
        });
    }
}
