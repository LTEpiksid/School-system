import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class AdminFrame extends JFrame {

    public static Connection getConnection() throws SQLException {
        final String DB_URL = "jdbc:mysql://localhost/student?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
        return DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
    }

    public void initialize() {
        JLabel titleLabel = new JLabel("Administratoriaus langas", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe Print", Font.BOLD, 20));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(titleLabel, BorderLayout.NORTH);

        JButton registrationButton = new JButton("Registravimas");
        JButton teachersButton = new JButton("Mokytojai");
        JButton studentsButton = new JButton("Studentai");

        registrationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openRegistrationWindow();
            }
        });

        teachersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openTeachersWindow();
            }
        });

        studentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAllStudentsWindow();
            }
        });

        JPanel buttonsPanel = new JPanel(new GridLayout(1, 3, 10, 0));
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        buttonsPanel.add(registrationButton);
        buttonsPanel.add(teachersButton);
        buttonsPanel.add(studentsButton);

        panel.add(buttonsPanel, BorderLayout.CENTER);

        setTitle("Administratoriaus langas");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);
        add(panel);
        setVisible(true);
    }

    private void openRegistrationWindow() {
        RegistrationFrame registrationFrame = new RegistrationFrame();
        registrationFrame.initialize();
    }

    private void openTeachersWindow() {
        TeachersFrame teachersFrame = new TeachersFrame();
        teachersFrame.initialize();
    }

    private void openAllStudentsWindow() {
        AllStudentsFrame allStudentsFrame = new AllStudentsFrame(); // Change the class name here
        allStudentsFrame.initialize();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AdminFrame adminFrame = new AdminFrame();
            adminFrame.initialize();
        });
    }
}
