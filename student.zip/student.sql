-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2023 at 09:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertStudentGrades` ()   BEGIN
    INSERT INTO subject_grades (user_id, subject_id, grade, date_id)
    SELECT u.id, s.subject_id, NULL, d.date_id
    FROM users u
    JOIN subjects s ON u.level = 'Student'
    CROSS JOIN dates d;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `dates`
--

CREATE TABLE `dates` (
  `date_id` int(11) NOT NULL,
  `date_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dates`
--

INSERT INTO `dates` (`date_id`, `date_name`) VALUES
(1, 'Rugsejis'),
(2, 'Spalis'),
(3, 'Lapkritis'),
(4, 'Gruodis');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subject_id` int(11) NOT NULL,
  `subject_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_id`, `subject_name`) VALUES
(1, 'Lie'),
(2, 'Mat'),
(3, 'Bio'),
(4, 'Ist'),
(5, 'Ang'),
(6, 'Fiz');

-- --------------------------------------------------------

--
-- Table structure for table `subject_grades`
--

CREATE TABLE `subject_grades` (
  `grade_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `grade` float DEFAULT NULL,
  `date_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subject_grades`
--

INSERT INTO `subject_grades` (`grade_id`, `user_id`, `subject_id`, `grade`, `date_id`) VALUES
(1, 2, 1, 10, 1),
(2, 2, 1, 10, 2),
(3, 2, 1, 4, 3),
(4, 2, 1, 2, 4),
(5, 2, 2, 7, 1),
(6, 2, 2, 6, 2),
(7, 2, 2, 5, 3),
(8, 2, 2, 4, 4),
(9, 2, 3, 0, 1),
(10, 2, 3, 0, 2),
(11, 2, 3, 0, 3),
(12, 2, 3, 0, 4),
(13, 2, 4, 0, 1),
(14, 2, 4, 0, 2),
(15, 2, 4, 2, 3),
(16, 2, 4, 0, 4),
(17, 2, 5, 4, 1),
(18, 2, 5, 5, 2),
(19, 2, 5, 0, 3),
(20, 2, 5, 0, 4),
(21, 2, 6, 10, 1),
(22, 2, 6, 10, 2),
(23, 2, 6, 10, 3),
(24, 2, 6, 10, 4),
(25, 3, 1, 0, 1),
(26, 3, 1, 0, 2),
(27, 3, 1, 0, 3),
(28, 3, 1, 0, 4),
(29, 3, 2, 6, 1),
(30, 3, 2, 0, 2),
(31, 3, 2, 0, 3),
(32, 3, 2, 0, 4),
(33, 3, 3, 0, 1),
(34, 3, 3, 0, 2),
(35, 3, 3, 0, 3),
(36, 3, 3, 0, 4),
(37, 3, 4, 8, 1),
(38, 3, 4, 0, 2),
(39, 3, 4, 0, 3),
(40, 3, 4, 0, 4),
(41, 3, 5, 0, 1),
(42, 3, 5, 0, 2),
(43, 3, 5, 0, 3),
(44, 3, 5, 0, 4),
(45, 3, 6, 0, 1),
(46, 3, 6, 0, 2),
(47, 3, 6, 0, 3),
(48, 3, 6, 0, 4),
(49, 4, 1, 0, 1),
(50, 4, 1, 0, 2),
(51, 4, 1, 0, 3),
(52, 4, 1, 0, 4),
(53, 4, 2, 0, 1),
(54, 4, 2, 0, 2),
(55, 4, 2, 0, 3),
(56, 4, 2, 0, 4),
(57, 4, 3, 0, 1),
(58, 4, 3, 0, 2),
(59, 4, 3, 0, 3),
(60, 4, 3, 0, 4),
(61, 4, 4, 0, 1),
(62, 4, 4, 0, 2),
(63, 4, 4, 0, 3),
(64, 4, 4, 0, 4),
(65, 4, 5, 0, 1),
(66, 4, 5, 0, 2),
(67, 4, 5, 0, 3),
(68, 4, 5, 0, 4),
(69, 4, 6, 0, 1),
(70, 4, 6, 0, 2),
(71, 4, 6, 0, 3),
(72, 4, 6, 0, 4),
(73, 7, 1, 0, 1),
(74, 7, 1, 0, 2),
(75, 7, 1, 0, 3),
(76, 7, 1, 0, 4),
(77, 7, 2, 0, 1),
(78, 7, 2, 0, 2),
(79, 7, 2, 0, 3),
(80, 7, 2, 0, 4),
(81, 7, 3, 0, 1),
(82, 7, 3, 0, 2),
(83, 7, 3, 0, 3),
(84, 7, 3, 0, 4),
(85, 7, 4, 0, 1),
(86, 7, 4, 0, 2),
(87, 7, 4, 0, 3),
(88, 7, 4, 0, 4),
(89, 7, 5, 0, 1),
(90, 7, 5, 0, 2),
(91, 7, 5, 0, 3),
(92, 7, 5, 0, 4),
(93, 7, 6, 0, 1),
(94, 7, 6, 0, 2),
(95, 7, 6, 0, 3),
(96, 7, 6, 0, 4),
(97, 2, 1, 10, 1),
(98, 2, 1, 10, 2),
(99, 2, 1, 4, 3),
(100, 2, 1, 2, 4),
(101, 2, 2, 7, 1),
(102, 2, 2, 6, 2),
(103, 2, 2, 5, 3),
(104, 2, 2, 4, 4),
(105, 2, 3, 0, 1),
(106, 2, 3, 0, 2),
(107, 2, 3, 0, 3),
(108, 2, 3, 0, 4),
(109, 2, 4, 0, 1),
(110, 2, 4, 0, 2),
(111, 2, 4, 2, 3),
(112, 2, 4, 0, 4),
(113, 2, 5, 4, 1),
(114, 2, 5, 5, 2),
(115, 2, 5, 0, 3),
(116, 2, 5, 0, 4),
(117, 2, 6, 10, 1),
(118, 2, 6, 10, 2),
(119, 2, 6, 10, 3),
(120, 2, 6, 10, 4),
(121, 3, 1, 0, 1),
(122, 3, 1, 0, 2),
(123, 3, 1, 0, 3),
(124, 3, 1, 0, 4),
(125, 3, 2, 6, 1),
(126, 3, 2, 0, 2),
(127, 3, 2, 0, 3),
(128, 3, 2, 0, 4),
(129, 3, 3, NULL, 1),
(130, 3, 3, NULL, 2),
(131, 3, 3, NULL, 3),
(132, 3, 3, NULL, 4),
(133, 3, 4, 8, 1),
(134, 3, 4, NULL, 2),
(135, 3, 4, NULL, 3),
(136, 3, 4, NULL, 4),
(137, 3, 5, NULL, 1),
(138, 3, 5, NULL, 2),
(139, 3, 5, NULL, 3),
(140, 3, 5, NULL, 4),
(141, 3, 6, NULL, 1),
(142, 3, 6, NULL, 2),
(143, 3, 6, NULL, 3),
(144, 3, 6, NULL, 4),
(145, 4, 1, 0, 1),
(146, 4, 1, 0, 2),
(147, 4, 1, 0, 3),
(148, 4, 1, NULL, 4),
(149, 4, 2, NULL, 1),
(150, 4, 2, NULL, 2),
(151, 4, 2, NULL, 3),
(152, 4, 2, NULL, 4),
(153, 4, 3, NULL, 1),
(154, 4, 3, NULL, 2),
(155, 4, 3, NULL, 3),
(156, 4, 3, NULL, 4),
(157, 4, 4, NULL, 1),
(158, 4, 4, NULL, 2),
(159, 4, 4, NULL, 3),
(160, 4, 4, NULL, 4),
(161, 4, 5, NULL, 1),
(162, 4, 5, NULL, 2),
(163, 4, 5, NULL, 3),
(164, 4, 5, NULL, 4),
(165, 4, 6, NULL, 1),
(166, 4, 6, NULL, 2),
(167, 4, 6, NULL, 3),
(168, 4, 6, NULL, 4),
(169, 7, 1, NULL, 1),
(170, 7, 1, NULL, 2),
(171, 7, 1, 0, 3),
(172, 7, 1, 0, 4),
(173, 7, 2, NULL, 1),
(174, 7, 2, 0, 2),
(175, 7, 2, NULL, 3),
(176, 7, 2, NULL, 4),
(177, 7, 3, NULL, 1),
(178, 7, 3, NULL, 2),
(179, 7, 3, NULL, 3),
(180, 7, 3, NULL, 4),
(181, 7, 4, NULL, 1),
(182, 7, 4, NULL, 2),
(183, 7, 4, NULL, 3),
(184, 7, 4, NULL, 4),
(185, 7, 5, NULL, 1),
(186, 7, 5, NULL, 2),
(187, 7, 5, NULL, 3),
(188, 7, 5, NULL, 4),
(189, 7, 6, NULL, 1),
(190, 7, 6, NULL, 2),
(191, 7, 6, NULL, 3),
(192, 7, 6, NULL, 4),
(224, 2, 1, 10, 1),
(225, 2, 1, 10, 2),
(226, 2, 1, 4, 3),
(227, 2, 1, 2, 4),
(228, 2, 2, 7, 1),
(229, 2, 2, 6, 2),
(230, 2, 2, 5, 3),
(231, 2, 2, 4, 4),
(232, 2, 3, 0, 1),
(233, 2, 3, 0, 2),
(234, 2, 3, 0, 3),
(235, 2, 3, 0, 4),
(236, 2, 4, 0, 1),
(237, 2, 4, 0, 2),
(238, 2, 4, 2, 3),
(239, 2, 4, 0, 4),
(240, 2, 5, 4, 1),
(241, 2, 5, 5, 2),
(242, 2, 5, 0, 3),
(243, 2, 5, 0, 4),
(244, 2, 6, 10, 1),
(245, 2, 6, 10, 2),
(246, 2, 6, 10, 3),
(247, 2, 6, 10, 4),
(248, 3, 1, 0, 1),
(249, 3, 1, 0, 2),
(250, 3, 1, 0, 3),
(251, 3, 1, 0, 4),
(252, 3, 2, 6, 1),
(253, 3, 2, 0, 2),
(254, 3, 2, 0, 3),
(255, 3, 2, 0, 4),
(256, 3, 3, NULL, 1),
(257, 3, 3, NULL, 2),
(258, 3, 3, NULL, 3),
(259, 3, 3, NULL, 4),
(260, 3, 4, 8, 1),
(261, 3, 4, NULL, 2),
(262, 3, 4, NULL, 3),
(263, 3, 4, NULL, 4),
(264, 3, 5, NULL, 1),
(265, 3, 5, NULL, 2),
(266, 3, 5, NULL, 3),
(267, 3, 5, NULL, 4),
(268, 3, 6, NULL, 1),
(269, 3, 6, NULL, 2),
(270, 3, 6, NULL, 3),
(271, 3, 6, NULL, 4),
(272, 4, 1, 0, 1),
(273, 4, 1, 0, 2),
(274, 4, 1, 0, 3),
(275, 4, 1, NULL, 4),
(276, 4, 2, NULL, 1),
(277, 4, 2, NULL, 2),
(278, 4, 2, NULL, 3),
(279, 4, 2, NULL, 4),
(280, 4, 3, NULL, 1),
(281, 4, 3, NULL, 2),
(282, 4, 3, NULL, 3),
(283, 4, 3, NULL, 4),
(284, 4, 4, NULL, 1),
(285, 4, 4, NULL, 2),
(286, 4, 4, NULL, 3),
(287, 4, 4, NULL, 4),
(288, 4, 5, NULL, 1),
(289, 4, 5, NULL, 2),
(290, 4, 5, NULL, 3),
(291, 4, 5, NULL, 4),
(292, 4, 6, NULL, 1),
(293, 4, 6, NULL, 2),
(294, 4, 6, NULL, 3),
(295, 4, 6, NULL, 4),
(296, 7, 1, NULL, 1),
(297, 7, 1, NULL, 2),
(298, 7, 1, NULL, 3),
(299, 7, 1, NULL, 4),
(300, 7, 2, NULL, 1),
(301, 7, 2, 0, 2),
(302, 7, 2, NULL, 3),
(303, 7, 2, NULL, 4),
(304, 7, 3, NULL, 1),
(305, 7, 3, NULL, 2),
(306, 7, 3, NULL, 3),
(307, 7, 3, NULL, 4),
(308, 7, 4, NULL, 1),
(309, 7, 4, NULL, 2),
(310, 7, 4, NULL, 3),
(311, 7, 4, NULL, 4),
(312, 7, 5, NULL, 1),
(313, 7, 5, NULL, 2),
(314, 7, 5, NULL, 3),
(315, 7, 5, NULL, 4),
(316, 7, 6, NULL, 1),
(317, 7, 6, NULL, 2),
(318, 7, 6, NULL, 3),
(319, 7, 6, NULL, 4);

-- --------------------------------------------------------

--
-- Table structure for table `teacher_subjects`
--

CREATE TABLE `teacher_subjects` (
  `assignment_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher_subjects`
--

INSERT INTO `teacher_subjects` (`assignment_id`, `user_id`, `subject_id`) VALUES
(0, 6, 1),
(1, 5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` varchar(50) NOT NULL,
  `groupe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `level`, `groupe`) VALUES
(1, 'Admin', 'Admin', 'Admin', '0'),
(2, 'Sidas', 'Dieliautas', 'Student', 'PI22B'),
(3, 'Lukas', 'Jurgutis', 'Student', 'PI22B'),
(4, 'Kristupas', 'Liudzius', 'Student', 'PI22B'),
(5, 'Mokytojas', 'Mokytojas', 'Teacher', '0'),
(6, 'Vienas', 'Du', 'Teacher', '0'),
(7, 'Laurynas', 'Blauzdys', 'Student', 'PI22A');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `after_insert_student` AFTER INSERT ON `users` FOR EACH ROW BEGIN
    IF NEW.level = 'Student' THEN
        SET @subject_id_counter = 1;
        SET @date_id_counter = 1;
        SET @grade_value = 0.0;

        -- Loop through subjects
        WHILE @subject_id_counter <= 6 DO
            -- Loop through dates
            WHILE @date_id_counter <= 4 DO
                INSERT INTO subject_grades (user_id, subject_id, grade, date_id)
                VALUES (NEW.id, @subject_id_counter, @grade_value, @date_id_counter);

                SET @date_id_counter = @date_id_counter + 1;
            END WHILE;

            -- Reset date_id_counter for the next subject
            SET @date_id_counter = 1;
            SET @subject_id_counter = @subject_id_counter + 1;
        END WHILE;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_insert_teacher` AFTER INSERT ON `users` FOR EACH ROW BEGIN
    IF NEW.level = 'Teacher' THEN
        INSERT INTO teacher_subjects (user_id, subject_id) VALUES (NEW.id, 1);
        -- Assuming subject_id 1 is the default subject for teachers
    END IF;
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dates`
--
ALTER TABLE `dates`
  ADD PRIMARY KEY (`date_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `subject_grades`
--
ALTER TABLE `subject_grades`
  ADD PRIMARY KEY (`grade_id`);

--
-- Indexes for table `teacher_subjects`
--
ALTER TABLE `teacher_subjects`
  ADD PRIMARY KEY (`assignment_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `subject_grades`
--
ALTER TABLE `subject_grades`
  MODIFY `grade_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=320;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
